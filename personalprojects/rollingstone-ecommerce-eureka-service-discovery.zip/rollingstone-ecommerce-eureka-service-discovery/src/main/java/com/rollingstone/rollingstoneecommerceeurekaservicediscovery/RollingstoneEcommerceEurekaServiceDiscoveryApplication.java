package com.rollingstone.rollingstoneecommerceeurekaservicediscovery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RollingstoneEcommerceEurekaServiceDiscoveryApplication {

	public static void main(String[] args) {
		SpringApplication.run(RollingstoneEcommerceEurekaServiceDiscoveryApplication.class, args);
	}

}
